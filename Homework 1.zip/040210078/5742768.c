// Kerem Bal - 040210078

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Node structure to store matrix data
typedef struct Node {
    int row, col, value;
    struct Node *next;
} Node;

// Function to read matrix data from a CSV file and create a linked list
Node *readMatrix(char *filename)
{
    Node *first_node = NULL, *current_node = NULL;

    // Opening CSV file to read
    FILE *fptr1 = fopen(filename, "r");
    if (fptr1 == NULL)
    {
        printf("File %s could not be opened.\n", filename);
        exit(1);
    }
    char row[1000];    // Creating a string for any row.
    int value, col_num, row_num = 0;

    while(fgets(row, 1000, fptr1) != NULL)    // Get each row as string, every loop is getting one line of matrix respectively
    {
        char *token = strtok(row, ",");    // Split each element of matrix by using the "," between them
        col_num = 0;
        while(token != NULL)    // Continue to splitting until the last element of corresponding row is achieved, every loop is getting one element of row respectively
        {
            value = atoi(token);    // Since the strtok function returns a string, we need to convert the value to the integer by using atoi function
            if(value != 0)      // Instead of append the zero values to the linked list, I wanted to keep that (row,col) value empty
            {
                // Initialize a new node to store recently read value
                Node *new_node = (Node *)malloc(sizeof(Node));
                new_node->row = row_num;
                new_node->col = col_num;
                new_node->value = value;
                new_node->next = NULL;
                
                if(first_node == NULL)  // Assign the new node to the head if the list is empty
                {
                    first_node = new_node;
                }
                else    // Append the new node to the end of the list if the list is not empty 
                {
                    current_node->next = new_node;
                }
                current_node = new_node;    // Update the current node
            }
            col_num++;  // Increase the column number by one when an element of corresponding row is appended to the linked list
            token = strtok(NULL, ",");
        }
        row_num++;  // Increase the row number by one when the operation of reading a row is completed
    }
    fclose(fptr1); // Close the CSV file
    return first_node;  // readMatrix function returns the head of matrix linked list
}

// Function to print matrix to the desired file
void printMatrix(Node *first_node, char *filename, int *nzeros)
{
    int num_rows = 0, num_cols = 0;
    Node *node = first_node;
    
    // That loop is very important to determine the maximum row and column of the matrix
    // We can convert any integer-entered CSV file to matrix even if each row (or each column) has not same dimension 
    // The integer-entered CSV file becomes a matrix after filling the empty areas (one of rows (or one of columns) has longer dimension) with zeros
    while(node != NULL)
    {
        if(node->row >= num_rows)
	    {
            num_rows = node->row + 1;
        }
        if(node->col >= num_cols)
	    {
            num_cols = node->col + 1;
        }
        node = node->next;
    }   // Eventually, in that loop, num_rows will be equal to [longest row]+[1] and num_cols will be equal to [longest column]+[1]

    // Open the output file for writing
    FILE *fptr2 = fopen(filename, "w");
    int i, j, inFile = 0; // I created a new integer for counting printed zeros, it should be in file to return its value to the main function
    if(fptr2 == NULL)
    {
        printf("File could not be opened.\n");
        exit(1);
    }
    
    // Display the matrix data and write it to the output file
    // Nested for loop just like reaching any element in a matrix which is in array form
    node = first_node;
    for (i = 0; i < num_rows; i++)
    {
        for (j = 0; j < num_cols; j++)
	    {
            if (node != NULL && node->row == i && node->col == j)   
		    {
                if (node->col == (num_cols-1))
                {
                    fprintf(fptr2, "%d", node->value);
                }
                else
                {
                    fprintf(fptr2, "%d,", node->value);
                }
                node = node->next;
            }
		    else
		    {
                if (node->col == (num_cols-1))
                {
                    fprintf(fptr2, "0");  // Filling the empty areas with zeros to convert non-matrix integer-valued CSV file to a matrix
                }
                else
                {
                    fprintf(fptr2, "0,"); // Filling the empty areas with zeros to convert non-matrix integer-valued CSV file to a matrix
                }
                inFile++;   // Counting printed zeros
            }
        }
        fprintf(fptr2, "\n"); // Passing another row
    }
fclose(fptr2);    // Close the output file
*nzeros = inFile;   // Assign the value of inFile to the nzeros, so we can access the nzeros through the main function
}

// Function to print duplicated elements to the desired file
void printDuplicates(char *filename, Node* first_node)
{
    // Not a perfect function beacuse it cannot count any duplicated value which is bigger than 99999 -size of array
    int hashTable[99999] = {0};  // All values initialized to zero
    Node* temp = first_node;

    // Open the output file for writing
    FILE *fptr3 = fopen(filename, "w");
    if(fptr3 == NULL)
    {
        printf("File could not be opened.\n");
        exit(1);
    }

    fprintf(fptr3, "Duplicates:\n");

    // The principal of the function is simple, it increases the value of hashTable[x] by one if the element x is read
    while (temp != NULL)
    {
        hashTable[temp->value]++;
        temp = temp->next;
    }

    temp = first_node;

    // When the reading is complete the function checks whether the value of hashTable[x] is bigger than one or not
    // If it is bigger than one, it means the hashTable[x] read more than once
    while (temp != NULL)
    {
        if (hashTable[temp->value] > 1)
        {
            fprintf(fptr3, "%d\n", temp->value);
            hashTable[temp->value] = 0; // Set back to zero to avoid any complication
        }
        temp = temp->next;
    }
    fclose(fptr3);
}

int main(int argc, char *argv[])
{
    int i, nzeros; // Creating an integer to use as input to get output of count of zeros

    Node *first_node = readMatrix("sample_input .csv"); // Reading matrix inside the "input.csv" file
    
    // Open the "result.txt" file for writing
	FILE *fptr4 = fopen("result.txt", "w");
	if(fptr4 == NULL)
    {
        printf("File could not be opened.\n");
        exit(1);
    }
    
	for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "--help") == 0) // Help menu configuration
        {
            printf("--print\t\t:\tPrints the given matrix inside of the input.csv file to an output text file.\n--nzeros\t:\tCalculates the number of zeros in the given matrix and prints the result in an output text file.\n--duplicates\t:\tFinds the duplicated element values in the given matrix and prints the result in an output text file.");
        }
        else if (strcmp(argv[i], "--print") == 0)   // Print option configuration
        {
            printMatrix(first_node, "result.txt", &nzeros); // Function call
        }
        else if (strcmp(argv[i], "--nzeros") == 0)  // Number of zeros option configuration
        {
            printMatrix(first_node, "result.txt", &nzeros);         // Data of number of zeros is provided by printMatrix function, so we need to call it
            fclose(fptr4);                                    // However, the job of printMatrix is actually printing the matrix and it is doing its job
            fptr4 = fopen("result.txt", "w");                 // We need to reset the "result.txt" file by re-opening it
            fprintf(fptr4, "Number of zeros:\n%d", nzeros);   // We can print number of zeros after resetting the previous data from the output file
        }
        else if (strcmp(argv[i], "--duplicates") == 0)  // Duplicated elements option configuration
        {
            printDuplicates("result.txt", first_node);  // Function call
        }
        else    // Unknown option configuration
        {
            printf("Unknown option: %s\n", argv[i]);
            exit(1);
        }
    }
	fclose(fptr4);    // Close the output file
	return 0;
}